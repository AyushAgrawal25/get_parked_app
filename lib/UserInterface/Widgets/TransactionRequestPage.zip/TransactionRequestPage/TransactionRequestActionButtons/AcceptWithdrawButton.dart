import 'package:flutter/material.dart';

class AcceptWithdrawButton extends StatefulWidget {
  @override
  _AcceptWithdrawButtonState createState() => _AcceptWithdrawButtonState();
}

class _AcceptWithdrawButtonState extends State<AcceptWithdrawButton> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
