import 'package:flutter/material.dart';

Color qbHeadColor = Color.fromRGBO(175, 175, 175, 1);
Color qbBodyColor = Color.fromRGBO(60, 60, 60, 1);
